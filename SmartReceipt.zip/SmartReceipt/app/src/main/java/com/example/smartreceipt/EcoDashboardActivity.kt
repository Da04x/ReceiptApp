package com.example.smartreceipt

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class EcoDashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_eco_dashboard)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Sustainability"

        val waterText = findViewById<TextView>(R.id.waterText)
        val carbonText = findViewById<TextView>(R.id.carbonText)
        val woodText = findViewById<TextView>(R.id.woodText)

        // 1. Get the total number of receipts the user has saved
        val totalReceipts = AppRepository.allReceipts().size

        // 2. Calculate the environmental impact
        // (Based on standard thermal receipt production averages)
        val waterSavedLiters = totalReceipts * 1.5
        val carbonSavedGrams = totalReceipts * 4.0
        val woodSavedGrams = totalReceipts * 2.5

        // 3. Format the text to look nice (e.g., 15.0 to "15")
        waterText.text = "${String.format("%.1f", waterSavedLiters)} Liters"
        carbonText.text = "${String.format("%.0f", carbonSavedGrams)} Grams"
        woodText.text = "${String.format("%.0f", woodSavedGrams)} Grams"

        // 4. Play the entry animation if enabled
        if (AppPreferences.animationsEnabled) {
            playEntryAnimation()
        }
    }

    private fun playEntryAnimation() {
        listOf<View>(
            findViewById(R.id.cardWater),
            findViewById(R.id.cardCarbon),
            findViewById(R.id.cardWood)
        ).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 30f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(300L)
                .setStartDelay(index * 100L) // Stagger the animation so they pop in one by one!
                .start()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}