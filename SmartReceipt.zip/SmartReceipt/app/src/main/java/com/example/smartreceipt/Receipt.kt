package com.example.smartreceipt

import java.util.UUID

data class Receipt(
    val id: String = UUID.randomUUID().toString(),
    val imageUri: String,
    val addedAt: Long = System.currentTimeMillis(),
    val merchantName: String = "",
    val amountLabel: String = "",
    val category: String = "General",
    val notes: String = ""
)
