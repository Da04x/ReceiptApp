package com.example.smartreceipt

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object ImageStorage {

    private const val RECEIPTS_DIR = "receipts"

    fun createTempCameraFile(context: Context): File {
        val cacheDir = requireNotNull(context.externalCacheDir ?: context.cacheDir)
        return File.createTempFile("receipt_capture_", ".jpg", cacheDir)
    }

    fun importImage(context: Context, sourceUri: Uri): String? {
        return runCatching {
            val receiptsDir = File(context.filesDir, RECEIPTS_DIR).apply { mkdirs() }
            val extension = extensionFor(sourceUri)
            val outputFile = File(
                receiptsDir,
                "receipt_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}$extension"
            )

            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(outputFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return null

            Uri.fromFile(outputFile).toString()
        }.getOrNull()
    }

    fun deleteManagedImage(context: Context, uriString: String) {
        val uri = Uri.parse(uriString)
        if (uri.scheme != "file") return

        val receiptsDir = File(context.filesDir, RECEIPTS_DIR).absolutePath
        val filePath = uri.path ?: return
        if (!filePath.startsWith(receiptsDir)) return

        File(filePath).takeIf { it.exists() }?.delete()
    }

    private fun extensionFor(uri: Uri): String {
        val path = uri.lastPathSegment.orEmpty().lowercase()
        return when {
            path.endsWith(".png") -> ".png"
            path.endsWith(".webp") -> ".webp"
            else -> ".jpg"
        }
    }
}
