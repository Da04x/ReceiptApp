package com.example.smartreceipt

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

object AppPreferences {

    const val THEME_SYSTEM = "system"
    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"

    private const val PREFS_NAME = "smart_receipt_settings"
    private const val KEY_THEME_MODE = "theme_mode"
    private const val KEY_ANIMATIONS = "animations_enabled"
    private const val KEY_CONFIRM_DELETE = "confirm_delete"
    private const val KEY_SORT_NEWEST = "sort_newest_first"

    private lateinit var prefs: android.content.SharedPreferences

    fun initialize(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, THEME_SYSTEM) ?: THEME_SYSTEM
        set(value) {
            prefs.edit().putString(KEY_THEME_MODE, value).apply()
            applyTheme()
        }

    var animationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_ANIMATIONS, true)
        set(value) {
            prefs.edit().putBoolean(KEY_ANIMATIONS, value).apply()
        }

    var confirmDeleteActions: Boolean
        get() = prefs.getBoolean(KEY_CONFIRM_DELETE, true)
        set(value) {
            prefs.edit().putBoolean(KEY_CONFIRM_DELETE, value).apply()
        }

    var sortNewestFirst: Boolean
        get() = prefs.getBoolean(KEY_SORT_NEWEST, true)
        set(value) {
            prefs.edit().putBoolean(KEY_SORT_NEWEST, value).apply()
        }

    fun applyTheme() {
        val nightMode = when (themeMode) {
            THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }

        AppCompatDelegate.setDefaultNightMode(nightMode)
    }
}
