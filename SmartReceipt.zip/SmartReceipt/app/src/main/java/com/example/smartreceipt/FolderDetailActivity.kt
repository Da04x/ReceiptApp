package com.example.smartreceipt

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FolderDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)

        val folder = AppRepository.getFolder(intent.getStringExtra("folderId"))
            ?: AppRepository.folders.firstOrNull {
                it.name == intent.getStringExtra("folder_name").orEmpty()
            }

        AppRepository.selectedFolder = folder
        startActivity(Intent(this, ScanReceiptActivity::class.java))
        finish()
    }
}
