package com.example.smartreceipt

import android.app.Application

class SmartReceiptApp : Application() {

    override fun onCreate() {
        super.onCreate()
        AppPreferences.initialize(this)
        AppPreferences.applyTheme()
        AppRepository.initialize(this)
    }
}
