package com.example.smartreceipt

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class ReceiptViewActivity : AppCompatActivity() {

    private lateinit var receipt: Receipt
    private lateinit var folderLabel: String

    private lateinit var assistantAnswerCard: View
    private lateinit var assistantAnswerText: TextView
    private lateinit var questionInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_receipt_view)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val receiptId = intent.getStringExtra(EXTRA_RECEIPT_ID)
        val foundReceipt = AppRepository.getReceipt(receiptId)
        if (foundReceipt == null) {
            Toast.makeText(this, "Couldn't load that receipt.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        receipt = foundReceipt
        folderLabel = AppRepository.folderLabelFor(receipt)
        supportActionBar?.title = AiHelper.titleFor(receipt)

        findViewById<ImageView>(R.id.fullImage).setImageURI(Uri.parse(receipt.imageUri))
        findViewById<TextView>(R.id.summaryText).text = AiHelper.buildSummary(receipt, folderLabel)
        findViewById<TextView>(R.id.amountText).text = receipt.amountLabel.ifBlank { "Not recorded" }
        findViewById<TextView>(R.id.categoryText).text = AiHelper.categoryFor(receipt)
        findViewById<TextView>(R.id.folderText).text = folderLabel
        findViewById<TextView>(R.id.dateText).text = java.text.DateFormat.getDateTimeInstance(
            java.text.DateFormat.MEDIUM,
            java.text.DateFormat.SHORT
        ).format(java.util.Date(receipt.addedAt))
        findViewById<TextView>(R.id.notesText).text =
            receipt.notes.ifBlank { "No notes were saved for this receipt." }

        questionInput = findViewById(R.id.assistantQuestionInput)
        assistantAnswerCard = findViewById(R.id.assistantAnswerCard)
        assistantAnswerText = findViewById(R.id.assistantAnswerText)

        findViewById<MaterialButton>(R.id.btnAskAssistant).setOnClickListener {
            askAssistant(questionInput.text.toString())
        }

        bindPromptChip(R.id.chipPromptSummary, "Give me a quick summary")
        bindPromptChip(R.id.chipPromptTotal, "What is the total?")
        bindPromptChip(R.id.chipPromptCategory, "What category is this?")
        bindPromptChip(R.id.chipPromptDate, "When was this saved?")

        if (AppPreferences.animationsEnabled) {
            playEntryAnimation()
        }
    }

    private fun bindPromptChip(chipId: Int, prompt: String) {
        findViewById<Chip>(chipId).setOnClickListener {
            questionInput.setText(prompt)
            askAssistant(prompt)
        }
    }

    private fun askAssistant(question: String) {
        val cleanQuestion = question.trim()
        if (cleanQuestion.isBlank()) return

        assistantAnswerCard.visibility = View.VISIBLE
        assistantAnswerText.text = "Looking at the receipt..." // Updated loading text!

        lifecycleScope.launch {
            // We are now passing 'this@ReceiptViewActivity' so the AI can open the image
            val aiResponse = AiHelper.askRealAi(
                this@ReceiptViewActivity,
                receipt,
                folderLabel,
                cleanQuestion
            )

            assistantAnswerText.text = aiResponse
        }
    }

    private fun playEntryAnimation() {
        listOf<View>(
            findViewById(R.id.imageCard),
            findViewById(R.id.summaryCard),
            findViewById(R.id.detailsCard),
            findViewById(R.id.assistantCard)
        ).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 22f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(240L)
                .setStartDelay(index * 70L)
                .start()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    companion object {
        const val EXTRA_RECEIPT_ID = "receiptId"
    }
}