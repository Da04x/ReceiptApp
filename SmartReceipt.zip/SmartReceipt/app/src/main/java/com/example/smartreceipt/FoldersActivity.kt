package com.example.smartreceipt

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FoldersActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var emptyCard: View
    private lateinit var overviewText: TextView
    private lateinit var addFolderButton: FloatingActionButton
    private lateinit var adapter: FolderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_folders)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Folders"

        recycler = findViewById(R.id.foldersRecycler)
        emptyCard = findViewById(R.id.emptyFoldersCard)
        overviewText = findViewById(R.id.folderOverviewText)
        addFolderButton = findViewById(R.id.fabAddFolder)

        recycler.layoutManager = LinearLayoutManager(this)

        adapter = FolderAdapter(
            AppRepository.folders,
            onClick = { folder ->
                AppRepository.selectedFolder = folder
                startActivity(Intent(this, ScanReceiptActivity::class.java))
            },
            onRename = { folder, newName ->
                val renamed = AppRepository.renameFolder(folder, newName)
                if (!renamed) {
                    Toast.makeText(this, "Use a unique folder name.", Toast.LENGTH_SHORT).show()
                }
                renamed
            },
            onDelete = { folder ->
                requestFolderDeletion(folder)
            }
        )

        recycler.adapter = adapter

        addFolderButton.setOnClickListener {
            showAddFolderDialog()
        }

        playEntryAnimation()
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
        updateUI()
    }

    private fun updateUI() {
        overviewText.text =
            "${AppRepository.folders.size} folders - ${AppRepository.allReceipts().size} receipts total"

        val hasFolders = AppRepository.folders.isNotEmpty()
        recycler.visibility = if (hasFolders) View.VISIBLE else View.GONE
        emptyCard.visibility = if (hasFolders) View.GONE else View.VISIBLE
    }

    private fun showAddFolderDialog() {
        val input = EditText(this)
        input.hint = "Folder name"

        AlertDialog.Builder(this)
            .setTitle("Create folder")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val folder = AppRepository.addFolder(input.text.toString())
                if (folder == null) {
                    Toast.makeText(
                        this,
                        "Use a unique folder name that isn't My Receipts.",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setPositiveButton
                }

                adapter.notifyDataSetChanged()
                updateUI()
                recycler.smoothScrollToPosition(AppRepository.folders.lastIndex)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun requestFolderDeletion(folder: Folder) {
        if (!AppPreferences.confirmDeleteActions) {
            deleteFolder(folder)
            return
        }

        val message = if (folder.receipts.isEmpty()) {
            "Delete ${folder.name}?"
        } else {
            "Delete ${folder.name}? Its receipts will be moved to ${AppRepository.ROOT_RECEIPTS_NAME}."
        }

        AlertDialog.Builder(this)
            .setTitle("Delete folder")
            .setMessage(message)
            .setPositiveButton("Delete") { _, _ ->
                deleteFolder(folder)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteFolder(folder: Folder) {
        AppRepository.deleteFolder(folder)
        adapter.notifyDataSetChanged()
        updateUI()
    }

    private fun playEntryAnimation() {
        if (!AppPreferences.animationsEnabled) {
            updateUI()
            return
        }

        findViewById<View>(R.id.folderHeaderCard).apply {
            alpha = 0f
            translationY = 24f
            animate().alpha(1f).translationY(0f).setDuration(260L).start()
        }
        recycler.alpha = 0f
        recycler.animate().alpha(1f).setDuration(280L).setStartDelay(80L).start()
        addFolderButton.scaleX = 0.8f
        addFolderButton.scaleY = 0.8f
        addFolderButton.animate().scaleX(1f).scaleY(1f).setStartDelay(120L).setDuration(220L).start()
        updateUI()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
