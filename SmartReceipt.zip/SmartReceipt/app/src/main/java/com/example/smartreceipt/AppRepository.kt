package com.example.smartreceipt

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AppRepository {

    const val ROOT_RECEIPTS_NAME = "My Receipts"

    private const val PREFS_NAME = "smart_receipt_prefs"
    private const val KEY_DATA = "app_data_json"

    private lateinit var appContext: Context
    private var initialized = false

    val looseReceipts: MutableList<Receipt> = mutableListOf()
    val folders: MutableList<Folder> = mutableListOf()

    var selectedFolder: Folder? = null

    fun initialize(context: Context) {
        if (initialized) return

        appContext = context.applicationContext
        AppPreferences.initialize(appContext)
        load()
        initialized = true
    }

    fun getFolder(folderId: String?): Folder? {
        return folders.firstOrNull { it.id == folderId }
    }

    fun getReceipt(receiptId: String?): Receipt? {
        if (receiptId.isNullOrBlank()) return null
        return allReceipts().firstOrNull { it.id == receiptId }
    }

    fun receiptsFor(folder: Folder?): List<Receipt> {
        val source = if (folder == null) {
            looseReceipts + folders.flatMap { it.receipts }
        } else {
            folder.receipts.toList()
        }
        return sortReceipts(source)
    }

    fun allReceipts(): List<Receipt> {
        return receiptsFor(null)
    }

    fun addFolder(name: String): Folder? {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return null
        if (cleanName.equals(ROOT_RECEIPTS_NAME, ignoreCase = true)) return null
        if (folders.any { it.name.equals(cleanName, ignoreCase = true) }) return null

        val folder = Folder(name = cleanName)
        folders.add(folder)
        save()
        return folder
    }

    fun renameFolder(folder: Folder, newName: String): Boolean {
        val cleanName = newName.trim()
        if (cleanName.isEmpty()) return false
        if (cleanName.equals(ROOT_RECEIPTS_NAME, ignoreCase = true)) return false
        if (folders.any { it.id != folder.id && it.name.equals(cleanName, ignoreCase = true) }) {
            return false
        }

        folder.name = cleanName
        save()
        return true
    }

    fun deleteFolder(folder: Folder): Boolean {
        looseReceipts.addAll(folder.receipts)
        folders.removeAll { it.id == folder.id }

        if (selectedFolder?.id == folder.id) {
            selectedFolder = null
        }

        save()
        return true
    }

    fun addReceipt(receipt: Receipt, folder: Folder?) {
        if (folder == null) {
            looseReceipts.add(receipt)
        } else {
            folder.receipts.add(receipt)
        }
        save()
    }

    fun deleteReceipt(receipt: Receipt, deleteImage: Boolean = true): Boolean {
        val removed = removeReceiptFromOwner(receipt.id)
        if (!removed) return false

        if (deleteImage) {
            ImageStorage.deleteManagedImage(appContext, receipt.imageUri)
        }

        save()
        return true
    }

    fun moveReceipt(receipt: Receipt, targetFolder: Folder?): Boolean {
        val owner = ownerFolderFor(receipt.id)
        val alreadyInRoot = owner == null && looseReceipts.any { it.id == receipt.id }

        if (targetFolder == null && alreadyInRoot) return false
        if (owner?.id == targetFolder?.id) return false

        val removed = removeReceiptFromOwner(receipt.id)
        if (!removed) return false

        if (targetFolder == null) {
            looseReceipts.add(receipt)
        } else {
            targetFolder.receipts.add(receipt)
        }

        save()
        return true
    }

    fun ownerFolderFor(receiptId: String): Folder? {
        return folders.firstOrNull { folder ->
            folder.receipts.any { it.id == receiptId }
        }
    }

    fun folderLabelFor(receipt: Receipt): String {
        return ownerFolderFor(receipt.id)?.name ?: ROOT_RECEIPTS_NAME
    }

    fun clearAllData() {
        val allStoredReceipts = looseReceipts + folders.flatMap { it.receipts }
        allStoredReceipts.forEach { ImageStorage.deleteManagedImage(appContext, it.imageUri) }

        looseReceipts.clear()
        folders.clear()
        selectedFolder = null
        save()
    }

    private fun removeReceiptFromOwner(receiptId: String): Boolean {
        val rootRemoved = looseReceipts.removeAll { it.id == receiptId }
        if (rootRemoved) return true

        folders.forEach { folder ->
            val removed = folder.receipts.removeAll { it.id == receiptId }
            if (removed) return true
        }

        return false
    }

    private fun sortReceipts(receipts: List<Receipt>): List<Receipt> {
        return if (AppPreferences.sortNewestFirst) {
            receipts.sortedByDescending { it.addedAt }
        } else {
            receipts.sortedBy { it.addedAt }
        }
    }

    private fun load() {
        folders.clear()
        looseReceipts.clear()

        val rawJson = prefs().getString(KEY_DATA, null).orEmpty()
        if (rawJson.isBlank()) return

        runCatching {
            if (rawJson.trim().startsWith("{")) {
                loadNewFormat(JSONObject(rawJson))
            } else {
                loadLegacyFolderArray(JSONArray(rawJson))
            }
        }.onFailure {
            folders.clear()
            looseReceipts.clear()
            prefs().edit().remove(KEY_DATA).apply()
        }
    }

    private fun loadNewFormat(rootJson: JSONObject) {
        val rootReceiptsJson = rootJson.optJSONArray("rootReceipts") ?: JSONArray()
        val foldersJson = rootJson.optJSONArray("folders") ?: JSONArray()

        for (receiptIndex in 0 until rootReceiptsJson.length()) {
            looseReceipts.add(parseReceipt(rootReceiptsJson.getJSONObject(receiptIndex)))
        }

        for (folderIndex in 0 until foldersJson.length()) {
            val folderJson = foldersJson.getJSONObject(folderIndex)
            val receipts = mutableListOf<Receipt>()
            val receiptsJson = folderJson.optJSONArray("receipts") ?: JSONArray()

            for (receiptIndex in 0 until receiptsJson.length()) {
                receipts.add(parseReceipt(receiptsJson.getJSONObject(receiptIndex)))
            }

            val folderName = folderJson.optString("name").trim()
            if (folderName.isNotBlank()) {
                folders.add(
                    Folder(
                        id = folderJson.optString("id").ifBlank { folderName },
                        name = folderName,
                        receipts = receipts
                    )
                )
            }
        }
    }

    private fun loadLegacyFolderArray(folderArray: JSONArray) {
        for (folderIndex in 0 until folderArray.length()) {
            val folderJson = folderArray.getJSONObject(folderIndex)
            val receiptsJson = folderJson.optJSONArray("receipts") ?: JSONArray()
            val receipts = mutableListOf<Receipt>()

            for (receiptIndex in 0 until receiptsJson.length()) {
                receipts.add(parseReceipt(receiptsJson.getJSONObject(receiptIndex)))
            }

            val folderName = folderJson.optString("name").trim()
            val legacyInbox = folderJson.optBoolean("isInbox", false) ||
                folderName.equals(ROOT_RECEIPTS_NAME, ignoreCase = true)

            if (legacyInbox) {
                looseReceipts.addAll(receipts)
            } else if (folderName.isNotBlank()) {
                folders.add(
                    Folder(
                        id = folderJson.optString("id").ifBlank { folderName },
                        name = folderName,
                        receipts = receipts
                    )
                )
            }
        }
    }

    private fun parseReceipt(receiptJson: JSONObject): Receipt {
        val legacyText = receiptJson.optString("extractedText")
        val merchantName = receiptJson.optString("merchantName").ifBlank {
            AiHelper.deriveMerchantName(legacyText)
        }
        val category = receiptJson.optString("category").ifBlank {
            AiHelper.suggestCategory(merchantName, legacyText, ROOT_RECEIPTS_NAME)
        }

        return Receipt(
            id = receiptJson.optString("id").ifBlank {
                receiptJson.optString("imageUri")
            },
            imageUri = receiptJson.optString("imageUri"),
            addedAt = receiptJson.optLong("addedAt", System.currentTimeMillis()),
            merchantName = merchantName,
            amountLabel = receiptJson.optString("amountLabel"),
            category = category,
            notes = receiptJson.optString("notes").ifBlank { legacyText }
        )
    }

    private fun save() {
        if (!::appContext.isInitialized) return

        val rootJson = JSONObject()
            .put("rootReceipts", receiptsToJson(looseReceipts))
            .put("folders", foldersToJson())

        prefs().edit().putString(KEY_DATA, rootJson.toString()).apply()
    }

    private fun foldersToJson(): JSONArray {
        val folderArray = JSONArray()

        folders.forEach { folder ->
            folderArray.put(
                JSONObject()
                    .put("id", folder.id)
                    .put("name", folder.name)
                    .put("receipts", receiptsToJson(folder.receipts))
            )
        }

        return folderArray
    }

    private fun receiptsToJson(receipts: List<Receipt>): JSONArray {
        val receiptArray = JSONArray()

        receipts.forEach { receipt ->
            receiptArray.put(
                JSONObject()
                    .put("id", receipt.id)
                    .put("imageUri", receipt.imageUri)
                    .put("addedAt", receipt.addedAt)
                    .put("merchantName", receipt.merchantName)
                    .put("amountLabel", receipt.amountLabel)
                    .put("category", receipt.category)
                    .put("notes", receipt.notes)
            )
        }

        return receiptArray
    }

    private fun prefs() = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
