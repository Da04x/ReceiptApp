package com.example.smartreceipt

import android.app.AlertDialog
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ReceiptAdapter(
    private val currentFolder: Folder?,
    private val onClick: (Receipt) -> Unit,
    private val onDelete: (Receipt) -> Unit,
    private val onMove: (Receipt, Folder?) -> Unit
) : RecyclerView.Adapter<ReceiptAdapter.ReceiptViewHolder>() {

    private val visibleReceipts = mutableListOf<Receipt>()

    fun submitList(receipts: List<Receipt>) {
        visibleReceipts.clear()
        visibleReceipts.addAll(receipts)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReceiptViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_receipt, parent, false)
        return ReceiptViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReceiptViewHolder, position: Int) {
        val receipt = visibleReceipts[position]
        val folderLabel = AppRepository.folderLabelFor(receipt)

        holder.imageView.setImageURI(Uri.parse(receipt.imageUri))
        holder.titleView.text = AiHelper.titleFor(receipt)
        holder.subtitleView.text = AiHelper.subtitleFor(receipt, folderLabel, currentFolder == null)
        holder.summaryView.text = AiHelper.previewFor(receipt, folderLabel)

        holder.itemView.setOnClickListener {
            onClick(receipt)
        }

        holder.itemView.setOnLongClickListener {
            val currentPosition = holder.adapterPosition
            if (currentPosition == RecyclerView.NO_POSITION) {
                return@setOnLongClickListener false
            }

            val currentReceipt = visibleReceipts[currentPosition]
            val options = arrayOf("Delete", "Move")

            AlertDialog.Builder(holder.itemView.context)
                .setTitle(AiHelper.titleFor(currentReceipt))
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> onDelete(currentReceipt)
                        1 -> showDestinationDialog(holder.itemView, currentReceipt)
                    }
                }
                .show()

            true
        }
    }

    override fun getItemCount() = visibleReceipts.size

    private fun showDestinationDialog(view: View, receipt: Receipt) {
        val context = view.context
        val destinations = mutableListOf<Pair<String, Folder?>>()
        destinations.add(AppRepository.ROOT_RECEIPTS_NAME to null)
        AppRepository.folders
            .filter { it.id != currentFolder?.id }
            .forEach { folder ->
                destinations.add(folder.name to folder)
            }

        if (destinations.size == 1 && currentFolder == null) {
            Toast.makeText(context, "Create a folder first.", Toast.LENGTH_SHORT).show()
            return
        }

        val labels = destinations.map { it.first }.toTypedArray()

        AlertDialog.Builder(context)
            .setTitle("Move receipt")
            .setItems(labels) { _, which ->
                onMove(receipt, destinations[which].second)
            }
            .show()
    }

    class ReceiptViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.receiptImage)
        val titleView: TextView = itemView.findViewById(R.id.receiptTitle)
        val subtitleView: TextView = itemView.findViewById(R.id.receiptSubtitle)
        val summaryView: TextView = itemView.findViewById(R.id.receiptSummary)
    }
}
