package com.example.smartreceipt

import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import kotlin.math.min
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.ai.client.generativeai.type.content


object AiHelper {

    fun titleFor(receipt: Receipt): String {
        return receipt.merchantName.ifBlank { "Receipt" }
    }

    fun categoryFor(receipt: Receipt): String {
        return receipt.category.ifBlank {
            suggestCategory(receipt.merchantName, receipt.notes, AppRepository.ROOT_RECEIPTS_NAME)
        }
    }

    fun subtitleFor(receipt: Receipt, folderLabel: String, includeFolder: Boolean): String {
        val dateLabel = shortDate(receipt.addedAt)
        val totalLabel = receipt.amountLabel.ifBlank { "No total" }

        return if (includeFolder) {
            "$folderLabel - $totalLabel - $dateLabel"
        } else {
            "$totalLabel - $dateLabel"
        }
    }

    fun previewFor(receipt: Receipt, folderLabel: String): String {
        val summary = buildSummary(receipt, folderLabel)
        return if (summary.length <= 120) summary else "${summary.take(117)}..."
    }

    fun buildSummary(receipt: Receipt, folderLabel: String): String {
        val title = titleFor(receipt)
        val category = categoryFor(receipt)
        val amountText = receipt.amountLabel.ifBlank { "No total has been recorded yet." }
        val noteText = receipt.notes.trim().ifBlank {
            "No extra notes were added for this receipt."
        }

        return buildString {
            append(title)
            append(" is saved in ")
            append(folderLabel)
            append(". Category: ")
            append(category)
            append(". ")
            if (receipt.amountLabel.isBlank()) {
                append(amountText)
            } else {
                append("Recorded total: ")
                append(amountText)
                append(".")
            }
            append(" Added on ")
            append(fullDate(receipt.addedAt))
            append(". Notes: ")
            append(noteText)
        }
    }

    suspend fun askRealAi(context: Context, receipt: Receipt, folderLabel: String, userQuestion: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val generativeModel = GenerativeModel(
                    modelName = "gemini-3-flash-preview", // Make sure this matches the model you got working!
                    apiKey = "AQ.Ab8RN6IiLvJVobRVKqZYMTGepaLbbmXE7aVpLG2vS_HVo1PzyQ"
                )

                // 1. Text Context
                val textContext = """
                    You are a helpful, friendly AI assistant inside a receipt management app called RecNest. 
                    Here are the text details currently saved for this receipt:
                    - Store/Merchant: ${titleFor(receipt)}
                    - Total Amount: ${receipt.amountLabel.ifBlank { "Unknown" }}
                    - Category: ${categoryFor(receipt)}
                    - Date Saved: ${fullDate(receipt.addedAt)}
                    - Saved in Folder: $folderLabel
                    - User Notes: ${receipt.notes.ifBlank { "None" }}
                """.trimIndent()

                // Tell the AI to look at the image if the text doesn't have the answer
                val promptText = "$textContext\n\nUser's Question: $userQuestion\n\nPlease answer the question accurately. If the user asks about something not explicitly listed in the text details (like a specific item price, tax, or date), look at the provided receipt image to find the answer."

                // 2. Load the actual image from the phone's storage
                val imageUri = Uri.parse(receipt.imageUri)
                val bitmap = context.contentResolver.openInputStream(imageUri)?.use {
                    BitmapFactory.decodeStream(it)
                }

                // 3. Send BOTH the image and the text prompt to Gemini!
                val inputContent = content {
                    if (bitmap != null) {
                        image(bitmap) // This is where we give the AI its "eyes"
                    }
                    text(promptText)
                }

                val response = generativeModel.generateContent(inputContent)
                response.text ?: "Sorry, I couldn't generate a response."

            } catch (e: Exception) {
                "Sorry, I'm having trouble connecting to my brain right now. (${e.localizedMessage})"
            }
        }
    }







    fun answerQuestion(receipt: Receipt, folderLabel: String, question: String): String {
        val cleanQuestion = question.trim()
        if (cleanQuestion.isBlank()) {
            return "Ask about the total, store, date, category, notes, or where the receipt is saved."
        }

        val lowerQuestion = cleanQuestion.lowercase()

        return when {
            lowerQuestion.contains("total") ||
                    lowerQuestion.contains("amount") ||
                    lowerQuestion.contains("cost") ||
                    lowerQuestion.contains("price") -> {
                if (receipt.amountLabel.isBlank()) {
                    "There isn't a recorded total for this receipt yet."
                } else {
                    "The recorded total for this receipt is ${receipt.amountLabel}."
                }
            }

            lowerQuestion.contains("store") ||
                    lowerQuestion.contains("merchant") ||
                    lowerQuestion.contains("shop") ||
                    lowerQuestion.contains("from") -> {
                "${titleFor(receipt)} is the saved merchant or store name for this receipt."
            }

            lowerQuestion.contains("category") ||
                    lowerQuestion.contains("type") -> {
                "This receipt is currently grouped as ${categoryFor(receipt)}."
            }

            lowerQuestion.contains("when") ||
                    lowerQuestion.contains("date") -> {
                "This receipt was added on ${fullDate(receipt.addedAt)}."
            }

            lowerQuestion.contains("folder") ||
                    lowerQuestion.contains("saved") ||
                    lowerQuestion.contains("where") -> {
                "This receipt is currently stored in $folderLabel."
            }

            lowerQuestion.contains("note") ||
                    lowerQuestion.contains("buy") ||
                    lowerQuestion.contains("about") ||
                    lowerQuestion.contains("for") -> {
                if (receipt.notes.isBlank()) {
                    "There aren't any notes saved for this receipt yet."
                } else {
                    "Saved notes: ${receipt.notes}"
                }
            }

            lowerQuestion.contains("refund") ||
                    lowerQuestion.contains("return") -> {
                buildString {
                    append("For a return or refund, keep the receipt from ")
                    append(titleFor(receipt))
                    append(" dated ")
                    append(shortDate(receipt.addedAt))
                    if (receipt.amountLabel.isNotBlank()) {
                        append(" with the recorded total of ")
                        append(receipt.amountLabel)
                    }
                    append(".")
                }
            }

            lowerQuestion.contains("summary") ||
                    lowerQuestion.contains("overview") -> buildSummary(receipt, folderLabel)

            else -> {
                "Here's the quick overview: ${buildSummary(receipt, folderLabel)}"
            }
        }
    }

    fun suggestCategory(merchant: String, notes: String, folderName: String): String {
        val text = "$merchant $notes $folderName".lowercase()

        return when {
            listOf("tesco", "aldi", "lidl", "sainsbury", "asda", "morrisons", "grocery")
                .any(text::contains) -> "Groceries"

            listOf("train", "uber", "flight", "petrol", "fuel", "taxi", "travel")
                .any(text::contains) -> "Travel"

            listOf("coffee", "restaurant", "cafe", "pizza", "burger", "bar")
                .any(text::contains) -> "Dining"

            listOf("internet", "electric", "gas", "water", "bill", "invoice")
                .any(text::contains) -> "Bills"

            listOf("amazon", "clothes", "fashion", "shopping", "store", "retail")
                .any(text::contains) -> "Shopping"

            listOf("office", "client", "meeting", "work")
                .any(text::contains) -> "Work"

            else -> "General"
        }
    }

    fun folderPreview(folder: Folder): String {
        val latestReceipt = folder.receipts.maxByOrNull { it.addedAt }
        return if (latestReceipt == null) {
            "Ready for your first receipt."
        } else {
            val merchant = titleFor(latestReceipt)
            val detail = latestReceipt.amountLabel.ifBlank { categoryFor(latestReceipt) }
            "Latest: $merchant - $detail"
        }
    }

    fun deriveMerchantName(legacyText: String): String {
        return legacyText
            .lineSequence()
            .map { it.trim() }
            .firstOrNull { it.length >= 3 && it.any(Char::isLetter) }
            ?.let { line -> line.take(min(28, line.length)) }
            .orEmpty()
    }

    fun matchesSearch(receipt: Receipt, folderLabel: String, query: String): Boolean {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) return true

        val haystack = listOf(
            titleFor(receipt),
            receipt.amountLabel,
            categoryFor(receipt),
            receipt.notes,
            folderLabel,
            buildSummary(receipt, folderLabel)
        ).joinToString(" ").lowercase()

        return haystack.contains(cleanQuery.lowercase())
    }

    private fun shortDate(timestamp: Long): String {
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(timestamp))
    }

    private fun fullDate(timestamp: Long): String {
        return DateFormat.getDateTimeInstance(
            DateFormat.MEDIUM,
            DateFormat.SHORT
        ).format(Date(timestamp))
    }
}