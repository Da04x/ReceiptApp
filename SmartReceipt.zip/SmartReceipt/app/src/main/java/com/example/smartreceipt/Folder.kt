package com.example.smartreceipt

import java.util.UUID

data class Folder(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val receipts: MutableList<Receipt> = mutableListOf()
) {
    fun receiptCount(): Int = receipts.size
}
