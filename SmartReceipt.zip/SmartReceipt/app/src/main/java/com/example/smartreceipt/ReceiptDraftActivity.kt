package com.example.smartreceipt

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class ReceiptDraftActivity : AppCompatActivity() {

    private lateinit var sourceUri: Uri

    private lateinit var receiptImage: ImageView
    private lateinit var selectedFolderText: TextView
    private lateinit var merchantInput: TextInputEditText
    private lateinit var amountInput: TextInputEditText
    private lateinit var categoryInput: AutoCompleteTextView
    private lateinit var notesInput: TextInputEditText
    private lateinit var previewText: TextView
    private lateinit var changeFolderButton: MaterialButton
    private lateinit var saveButton: MaterialButton

    private var selectedFolder: Folder? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_receipt_draft)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Add Receipt"

        receiptImage = findViewById(R.id.draftImage)
        selectedFolderText = findViewById(R.id.selectedFolderText)
        merchantInput = findViewById(R.id.merchantInput)
        amountInput = findViewById(R.id.amountInput)
        categoryInput = findViewById(R.id.categoryInput)
        notesInput = findViewById(R.id.notesInput)
        previewText = findViewById(R.id.assistantPreviewText)
        changeFolderButton = findViewById(R.id.btnChangeFolder)
        saveButton = findViewById(R.id.btnSaveReceipt)

        val imageUriString = intent.getStringExtra(EXTRA_IMAGE_URI)
        if (imageUriString == null) {
            finish()
            return
        }

        sourceUri = Uri.parse(imageUriString)
        selectedFolder = AppRepository.getFolder(intent.getStringExtra(EXTRA_FOLDER_ID))
        receiptImage.setImageURI(sourceUri)

        val categoryOptions = listOf(
            "General",
            "Groceries",
            "Dining",
            "Travel",
            "Shopping",
            "Bills",
            "Work",
            "Personal"
        )
        categoryInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categoryOptions)
        )
        categoryInput.setText("General", false)

        updateFolderText()
        updatePreview()

        listOf(merchantInput, amountInput, notesInput).forEach { input ->
            input.doAfterTextChanged { updatePreview() }
        }
        categoryInput.doAfterTextChanged { updatePreview() }

        changeFolderButton.setOnClickListener {
            showFolderPicker()
        }

        saveButton.setOnClickListener {
            saveReceipt()
        }

        if (AppPreferences.animationsEnabled) {
            playEntryAnimation()
        }
    }

    private fun showFolderPicker() {
        val labels = mutableListOf(AppRepository.ROOT_RECEIPTS_NAME)
        labels.addAll(AppRepository.folders.map { it.name })

        AlertDialog.Builder(this)
            .setTitle("Save location")
            .setItems(labels.toTypedArray()) { _, which ->
                selectedFolder = if (which == 0) null else AppRepository.folders[which - 1]
                updateFolderText()
                updatePreview()
            }
            .show()
    }

    private fun saveReceipt() {
        val storedImageUri = ImageStorage.importImage(this, sourceUri)
        if (storedImageUri == null) {
            Toast.makeText(this, "Couldn't save the receipt image.", Toast.LENGTH_SHORT).show()
            return
        }

        val merchant = merchantInput.text?.toString().orEmpty().trim()
        val notes = notesInput.text?.toString().orEmpty().trim()
        val category = categoryInput.text?.toString().orEmpty().trim()
            .ifBlank { AiHelper.suggestCategory(merchant, notes, selectedFolder?.name.orEmpty()) }

        AppRepository.addReceipt(
            Receipt(
                imageUri = storedImageUri,
                merchantName = merchant,
                amountLabel = amountInput.text?.toString().orEmpty().trim(),
                category = category,
                notes = notes
            ),
            selectedFolder
        )

        setResult(Activity.RESULT_OK)
        Toast.makeText(
            this,
            "Receipt saved to ${selectedFolder?.name ?: AppRepository.ROOT_RECEIPTS_NAME}.",
            Toast.LENGTH_SHORT
        ).show()
        finish()
    }

    private fun updateFolderText() {
        selectedFolderText.text = selectedFolder?.name ?: AppRepository.ROOT_RECEIPTS_NAME
    }

    private fun updatePreview() {
        val draftReceipt = Receipt(
            imageUri = sourceUri.toString(),
            merchantName = merchantInput.text?.toString().orEmpty().trim(),
            amountLabel = amountInput.text?.toString().orEmpty().trim(),
            category = categoryInput.text?.toString().orEmpty().trim()
                .ifBlank {
                    AiHelper.suggestCategory(
                        merchantInput.text?.toString().orEmpty(),
                        notesInput.text?.toString().orEmpty(),
                        selectedFolder?.name.orEmpty()
                    )
                },
            notes = notesInput.text?.toString().orEmpty().trim()
        )

        previewText.text = AiHelper.buildSummary(
            draftReceipt,
            selectedFolder?.name ?: AppRepository.ROOT_RECEIPTS_NAME
        )
    }

    private fun playEntryAnimation() {
        listOf<View>(
            findViewById(R.id.imageCard),
            findViewById(R.id.detailsCard),
            findViewById(R.id.previewCard)
        ).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 24f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(250L)
                .setStartDelay(index * 70L)
                .start()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    companion object {
        const val EXTRA_IMAGE_URI = "imageUri"
        const val EXTRA_FOLDER_ID = "folderId"
    }
}
