package com.example.smartreceipt

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FolderAdapter(
    private val folders: MutableList<Folder>,
    private val onClick: (Folder) -> Unit,
    private val onRename: (Folder, String) -> Boolean,
    private val onDelete: (Folder) -> Unit
) : RecyclerView.Adapter<FolderAdapter.FolderVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderVH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_folder, parent, false)
        return FolderVH(view)
    }

    override fun onBindViewHolder(holder: FolderVH, position: Int) {
        val folder = folders[position]

        holder.name.text = folder.name
        holder.count.text = "${folder.receiptCount()} receipts"
        holder.preview.text = AiHelper.folderPreview(folder)

        holder.itemView.setOnClickListener {
            onClick(folder)
        }

        holder.itemView.setOnLongClickListener {
            val currentPosition = holder.adapterPosition
            if (currentPosition == RecyclerView.NO_POSITION) {
                return@setOnLongClickListener false
            }

            val currentFolder = folders[currentPosition]

            AlertDialog.Builder(holder.itemView.context)
                .setTitle(currentFolder.name)
                .setItems(arrayOf("Rename", "Delete")) { _, which ->
                    when (which) {
                        0 -> showRenameDialog(holder.itemView, currentFolder)
                        1 -> onDelete(currentFolder)
                    }
                }
                .show()

            true
        }
    }

    override fun getItemCount() = folders.size

    private fun showRenameDialog(view: View, folder: Folder) {
        val input = EditText(view.context)
        input.setText(folder.name)

        AlertDialog.Builder(view.context)
            .setTitle("Rename folder")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                if (onRename(folder, input.text.toString())) {
                    notifyDataSetChanged()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    class FolderVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.folderName)
        val count: TextView = itemView.findViewById(R.id.folderCount)
        val preview: TextView = itemView.findViewById(R.id.folderPreview)
    }
}
