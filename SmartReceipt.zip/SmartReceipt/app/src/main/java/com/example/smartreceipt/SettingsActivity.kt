package com.example.smartreceipt

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup

class SettingsActivity : AppCompatActivity() {

    private lateinit var statsText: TextView
    private lateinit var themeGroup: MaterialButtonToggleGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_settings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"

        statsText = findViewById(R.id.statsText)
        themeGroup = findViewById(R.id.themeToggleGroup)
        val resetButton = findViewById<MaterialButton>(R.id.btnResetData)

        bindThemeSelection()

        resetButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset app data")
                .setMessage("Delete every saved receipt and folder from this device?")
                .setPositiveButton("Reset") { _, _ ->
                    AppRepository.clearAllData()
                    updateStats()
                    Toast.makeText(this, "App data cleared.", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        updateStats()

        if (AppPreferences.animationsEnabled) {
            playEntryAnimation()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStats()
    }

    private fun bindThemeSelection() {
        val checkedId = when (AppPreferences.themeMode) {
            AppPreferences.THEME_LIGHT -> R.id.btnThemeLight
            AppPreferences.THEME_DARK -> R.id.btnThemeDark
            else -> R.id.btnThemeSystem
        }
        themeGroup.check(checkedId)

        themeGroup.addOnButtonCheckedListener { _, checkedButtonId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener

            AppPreferences.themeMode = when (checkedButtonId) {
                R.id.btnThemeLight -> AppPreferences.THEME_LIGHT
                R.id.btnThemeDark -> AppPreferences.THEME_DARK
                else -> AppPreferences.THEME_SYSTEM
            }
        }
    }

    private fun updateStats() {
        statsText.text =
            "Receipts: ${AppRepository.allReceipts().size}\nFolders: ${AppRepository.folders.size}"
    }

    private fun playEntryAnimation() {
        listOf<View>(
            findViewById(R.id.appearanceCard),
            findViewById(R.id.dataCard)
        ).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 24f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(240L)
                .setStartDelay(index * 70L)
                .start()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}