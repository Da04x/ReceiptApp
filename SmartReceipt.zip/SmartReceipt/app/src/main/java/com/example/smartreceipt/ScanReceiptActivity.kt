package com.example.smartreceipt

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ScanReceiptActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyCard: View
    private lateinit var folderTitle: TextView
    private lateinit var folderSubtitle: TextView
    private lateinit var receiptCountText: TextView
    private lateinit var searchButton: ImageButton
    private lateinit var mainFab: FloatingActionButton
    private lateinit var cameraRow: View
    private lateinit var galleryRow: View
    private lateinit var cameraFab: FloatingActionButton
    private lateinit var galleryFab: FloatingActionButton
    private lateinit var scrim: View

    private var currentFolder: Folder? = null
    private lateinit var adapter: ReceiptAdapter

    private var pendingCameraUri: Uri? = null
    private var searchQuery = ""
    private var isFabMenuOpen = false

    // NEW: This handles asking the user for Camera permission safely
    private val requestCameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                openCamera()
            } else {
                Toast.makeText(this, "Camera permission is required to snap receipts.", Toast.LENGTH_LONG).show()
            }
        }

    private val draftLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                refreshFolder()
                refreshReceipts()
            }
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                pendingCameraUri?.let(::openDraft)
            }
        }

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let(::openDraft)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_scan_receipt)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = ""

        recyclerView = findViewById(R.id.receiptsRecycler)
        emptyCard = findViewById(R.id.emptyStateCard)
        folderTitle = findViewById(R.id.folderTitle)
        folderSubtitle = findViewById(R.id.folderSubtitle)
        receiptCountText = findViewById(R.id.receiptCountText)
        searchButton = findViewById(R.id.btnSearch)
        mainFab = findViewById(R.id.fabAddReceipt)
        cameraRow = findViewById(R.id.fabOptionCameraRow)
        galleryRow = findViewById(R.id.fabOptionGalleryRow)
        cameraFab = findViewById(R.id.fabCameraOption)
        galleryFab = findViewById(R.id.fabGalleryOption)
        scrim = findViewById(R.id.fabScrim)

        currentFolder = AppRepository.selectedFolder

        adapter = ReceiptAdapter(
            currentFolder = currentFolder,
            onClick = { receipt ->
                startActivity(
                    Intent(this, ReceiptViewActivity::class.java)
                        .putExtra(ReceiptViewActivity.EXTRA_RECEIPT_ID, receipt.id)
                )
            },
            onDelete = { receipt ->
                requestReceiptDeletion(receipt)
            },
            onMove = { receipt, targetFolder ->
                val moved = AppRepository.moveReceipt(receipt, targetFolder)
                if (!moved) {
                    Toast.makeText(this, "That receipt is already there.", Toast.LENGTH_SHORT).show()
                } else {
                    refreshFolder()
                    refreshReceipts()
                    Toast.makeText(
                        this,
                        "Moved to ${targetFolder?.name ?: AppRepository.ROOT_RECEIPTS_NAME}.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        recyclerView.adapter = adapter

        mainFab.setOnClickListener {
            toggleFabMenu()
        }

        // UPDATED: Now uses checkAndOpenCamera() instead of openCamera()
        cameraFab.setOnClickListener {
            closeFabMenu()
            checkAndOpenCamera()
        }
        galleryFab.setOnClickListener {
            closeFabMenu()
            galleryLauncher.launch("image/*")
        }

        // UPDATED: Now uses checkAndOpenCamera()
        cameraRow.setOnClickListener {
            closeFabMenu()
            checkAndOpenCamera()
        }
        galleryRow.setOnClickListener {
            closeFabMenu()
            galleryLauncher.launch("image/*")
        }

        scrim.setOnClickListener {
            closeFabMenu()
        }
        searchButton.setOnClickListener {
            showSearchDialog()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isFabMenuOpen) {
                    closeFabMenu()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (AppPreferences.animationsEnabled) {
            playEntryAnimation()
        }

        refreshFolder()
        refreshReceipts()
    }

    override fun onResume() {
        super.onResume()
        refreshFolder()
        refreshReceipts()
    }

    private fun requestReceiptDeletion(receipt: Receipt) {
        if (!AppPreferences.confirmDeleteActions) {
            deleteReceipt(receipt)
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Delete receipt")
            .setMessage("Delete ${AiHelper.titleFor(receipt)}?")
            .setPositiveButton("Delete") { _, _ ->
                deleteReceipt(receipt)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteReceipt(receipt: Receipt) {
        AppRepository.deleteReceipt(receipt)
        refreshFolder()
        refreshReceipts()
        Toast.makeText(this, "Receipt deleted.", Toast.LENGTH_SHORT).show()
    }

    private fun refreshFolder() {
        currentFolder = currentFolder?.let { AppRepository.getFolder(it.id) }
        AppRepository.selectedFolder = currentFolder

        val title = currentFolder?.name ?: AppRepository.ROOT_RECEIPTS_NAME
        folderTitle.text = title
        folderSubtitle.text = if (currentFolder == null) {
            "Everything you have saved, organized in one place."
        } else {
            "Keep this folder tidy and easy to review."
        }
    }

    private fun refreshReceipts() {
        val receipts = AppRepository.receiptsFor(currentFolder)
            .filter { receipt ->
                AiHelper.matchesSearch(receipt, AppRepository.folderLabelFor(receipt), searchQuery)
            }

        receiptCountText.text = "${receipts.size} receipts"
        adapter.submitList(receipts)
        emptyCard.visibility = if (receipts.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (receipts.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showSearchDialog() {
        val input = EditText(this)
        input.setText(searchQuery)
        input.hint = "Search store, amount, notes, or folder"

        AlertDialog.Builder(this)
            .setTitle("Search receipts")
            .setView(input)
            .setPositiveButton("Search") { _, _ ->
                searchQuery = input.text.toString().trim()
                refreshReceipts()
            }
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Clear") { _, _ ->
                searchQuery = ""
                refreshReceipts()
            }
            .show()
    }

    // NEW: Safely checks for permission before launching the camera
    private fun checkAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera() // We already have permission, safe to open!
        } else {
            // We don't have permission yet, ask the user!
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun openCamera() {
        val file = ImageStorage.createTempCameraFile(this)
        pendingCameraUri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.provider",
            file
        )

        pendingCameraUri?.let(cameraLauncher::launch)
    }

    private fun openDraft(uri: Uri) {
        draftLauncher.launch(
            Intent(this, ReceiptDraftActivity::class.java)
                .putExtra(ReceiptDraftActivity.EXTRA_IMAGE_URI, uri.toString())
                .putExtra(ReceiptDraftActivity.EXTRA_FOLDER_ID, currentFolder?.id)
        )
    }

    private fun toggleFabMenu() {
        if (isFabMenuOpen) closeFabMenu() else openFabMenu()
    }

    private fun openFabMenu() {
        isFabMenuOpen = true
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(180L).start()

        listOf(galleryRow, cameraRow).forEachIndexed { index, row ->
            row.visibility = View.VISIBLE
            if (AppPreferences.animationsEnabled) {
                row.alpha = 0f
                row.translationY = 22f
                row.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(220L)
                    .setStartDelay(index * 50L)
                    .start()
            } else {
                row.alpha = 1f
                row.translationY = 0f
            }
        }

        mainFab.animate().rotation(45f).setDuration(180L).start()
    }

    private fun closeFabMenu() {
        if (!isFabMenuOpen) return
        isFabMenuOpen = false

        scrim.animate()
            .alpha(0f)
            .setDuration(140L)
            .withEndAction { scrim.visibility = View.GONE }
            .start()

        listOf(cameraRow, galleryRow).forEach { row ->
            if (AppPreferences.animationsEnabled) {
                row.animate()
                    .alpha(0f)
                    .translationY(16f)
                    .setDuration(140L)
                    .withEndAction { row.visibility = View.INVISIBLE }
                    .start()
            } else {
                row.visibility = View.INVISIBLE
            }
        }

        mainFab.animate().rotation(0f).setDuration(140L).start()
    }

    private fun playEntryAnimation() {
        listOf(findViewById<View>(R.id.headerCard), recyclerView, mainFab).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 20f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(240L)
                .setStartDelay(index * 70L)
                .start()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        if (isFabMenuOpen) {
            closeFabMenu()
            return true
        }
        finish()
        return true
    }
}