package com.example.smartreceipt

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var receiptCountValue: TextView
    private lateinit var folderCountValue: TextView
    private lateinit var heroCard: MaterialCardView
    private lateinit var receiptsCard: MaterialCardView
    private lateinit var foldersCard: MaterialCardView
    private lateinit var settingsCard: MaterialCardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRepository.initialize(applicationContext)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        receiptCountValue = findViewById(R.id.receiptCountValue)
        folderCountValue = findViewById(R.id.folderCountValue)
        heroCard = findViewById(R.id.heroCard)
        receiptsCard = findViewById(R.id.cardMyReceipts)
        foldersCard = findViewById(R.id.cardFolders)
        settingsCard = findViewById(R.id.cardSettings)

        findViewById<View>(R.id.cardEcoImpact).setOnClickListener {
            startActivity(Intent(this, EcoDashboardActivity::class.java))
        }

        receiptsCard.setOnClickListener {
            AppRepository.selectedFolder = null
            startActivity(Intent(this, ScanReceiptActivity::class.java))
        }

        foldersCard.setOnClickListener {
            startActivity(Intent(this, FoldersActivity::class.java))
        }

        settingsCard.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        playEntryAnimation()
    }

    override fun onResume() {
        super.onResume()
        updateStats()
    }

    private fun updateStats() {
        receiptCountValue.text = AppRepository.allReceipts().size.toString()
        folderCountValue.text = AppRepository.folders.size.toString()
    }

    private fun playEntryAnimation() {
        if (!AppPreferences.animationsEnabled) return

        listOf<View>(heroCard, receiptsCard, foldersCard, settingsCard).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 36f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(280L)
                .setStartDelay(index * 70L)
                .start()
        }
    }
}
